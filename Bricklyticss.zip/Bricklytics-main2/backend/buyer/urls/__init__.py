"""
buyer urls package
"""
