"""
buyer app package
"""
