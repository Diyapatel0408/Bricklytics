"""
accounts urls package
"""
