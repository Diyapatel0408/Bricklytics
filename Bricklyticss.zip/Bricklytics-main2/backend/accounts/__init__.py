"""
accounts app package initialization
"""
